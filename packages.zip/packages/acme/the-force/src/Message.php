<?php

namespace Acme\TheForce;

class Message 

{
	public function displayMessage($message = 'The Force Awakens!')

	{
		return $message;
	}
}

